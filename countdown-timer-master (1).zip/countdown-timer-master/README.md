Countdown Timer Widget
===============

Countdown timer widget for Android.

App in [Play Store](https://play.google.com/store/apps/details?id=de.dimond.countdowntimer)
